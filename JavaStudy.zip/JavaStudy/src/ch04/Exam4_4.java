package ch04;

public class Exam4_4 {
	public static void main(String[] args) {
		
		int total = 0;
		for(int a = 1 ; a <= 99 ; a++) {
			total = total  + a;
		}
		System.out.println(total);
	}
}
