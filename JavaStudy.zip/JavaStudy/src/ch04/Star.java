package ch04;

public class Star {
	public static void main(String[] args) {
		//�Ƕ�̵� �����
//		for (int a = 1; a <= 10; a++) {
//			for (int b = 1; b <= a; b++) {
//				System.out.print("��");
//			}
//			System.out.println();
//		}
		//�Ƕ�̵� �Ųٷ�
		for (int a = 10 ; a >= 1 ; a--) {
			for (int b = 1 ; b <= a; b++) {
				System.out.print("��");
			} System.out.println();
		} 

	}

}
