package ch04;

public class While1 {
	public static void main(String[] args) {
		int i = 10;
		while (i >=0) {
			System.out.print(i-- + " ");
		}
		System.out.println();
		for (int a = 10 ; a>=0 ; a--) {
			System.out.print(a + " ");
		}
	}
}
