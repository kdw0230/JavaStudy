package ch02;

public class Variable2 {
	public static void main(String[] args) {
		
	}
}
