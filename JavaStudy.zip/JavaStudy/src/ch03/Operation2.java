package ch03;

import java.util.Scanner;

public class Operation2 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		boolean ��� = num % 3 == 0;
		System.out.println(���);
		s.close();
	}
}
