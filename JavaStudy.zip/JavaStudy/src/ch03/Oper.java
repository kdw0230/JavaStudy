package ch03;

public class Oper {
	public static void main(String[] args) {
		int count = 0;
//		count = 1;
		count += 1;// count = count + 1;
		count++;// count = count + 1;
		System.out.println(count);
		
	}

}
