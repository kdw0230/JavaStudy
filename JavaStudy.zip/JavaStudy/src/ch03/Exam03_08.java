package ch03;

public class Exam03_08 {
	public static void main(String[] args) {
		 int num = 10;
		 System.out.println( 
				 (num>0) ? '��' : ( num == 0 ? "0" : "����" ) 
		 ); 
	}

}
