package ch01;

public class Exam01_2 {
	public static void main(String[] args) {
		/* 
		 * {"id":"ggoreb", "pw":"abcd", "name":"kim", "age":20}
		 */
		System.out.println("{\"id\":\"ggoreb\", \"pw\":\"abcd\", \"name\":\"kim\", \"age\":20}");
	}
}
